import 'package:flutter/material.dart';
import 'home_page.dart';

class SurveyPage extends StatefulWidget {
  @override
  _SurveyPageState createState() => _SurveyPageState();
}

class _SurveyPageState extends State<SurveyPage> {
  bool isStudent = false;
  bool isOther = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF00DBDE), Color(0xFFFC00FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // 🔹 Title
                Text(
                  'Are you a Student or Others?',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 20),

                // 🔹 Student Checkbox
                GestureDetector(
                  onTap: () {
                    setState(() {
                      isStudent = true;
                      isOther = false;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: isStudent ? Colors.white : Colors.transparent,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.white, width: 2),
                      boxShadow: isStudent
                          ? [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ]
                          : [],
                    ),
                    padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                    child: Row(
                      children: [
                        Icon(Icons.school, color: isStudent ? Colors.black : Colors.white),
                        SizedBox(width: 10),
                        Text(
                          "Student",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: isStudent ? Colors.black : Colors.white,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          isStudent ? Icons.check_circle : Icons.radio_button_unchecked,
                          color: isStudent ? Colors.green : Colors.white,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 15),

                // 🔹 Others Checkbox
                GestureDetector(
                  onTap: () {
                    setState(() {
                      isOther = true;
                      isStudent = false;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: isOther ? Colors.white : Colors.transparent,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.white, width: 2),
                      boxShadow: isOther
                          ? [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ]
                          : [],
                    ),
                    padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                    child: Row(
                      children: [
                        Icon(Icons.work, color: isOther ? Colors.black : Colors.white),
                        SizedBox(width: 10),
                        Text(
                          "Others",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: isOther ? Colors.black : Colors.white,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          isOther ? Icons.check_circle : Icons.radio_button_unchecked,
                          color: isOther ? Colors.green : Colors.white,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 30),

                // 🔹 Continue Button
                GestureDetector(
                  onTap: (isStudent || isOther)
                      ? () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  }
                      : null,
                  child: Container(
                    width: 200,
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isStudent || isOther
                            ? [Color(0xFF00DBDE), Color(0xFFFC00FF)]
                            : [Colors.grey, Colors.grey],
                      ),
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: isStudent || isOther
                          ? [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ]
                          : [],
                    ),
                    child: Center(
                      child: Text(
                        'Continue',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
