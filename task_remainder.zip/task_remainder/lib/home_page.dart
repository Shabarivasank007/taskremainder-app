import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'task_details_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'package:animated_text_kit/animated_text_kit.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  String greetingMessage = "";

  List<Map<String, dynamic>> tasks = [];

  @override
  void initState() {
    super.initState();
    _updateGreeting();
    _loadTasks();
    Timer.periodic(Duration(minutes: 1), (timer) => _updateGreeting());
  }

  void _loadTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? tasksString = prefs.getString('tasks');
    if (tasksString != null) {
      List<dynamic> taskList = jsonDecode(tasksString);
      setState(() {
        tasks = List<Map<String, dynamic>>.from(taskList);
      });
    }
  }

  void _saveTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String tasksString = jsonEncode(tasks);
    prefs.setString('tasks', tasksString);
  }

  void _updateGreeting() {
    final hour = DateTime.now().hour;
    String message;
    if (hour < 12) {
      message = "Good Morning! ☀️";
    } else if (hour < 17) {
      message = "Good Afternoon! 🌤️";
    } else if (hour < 20) {
      message = "Good Evening! 🌆";
    } else {
      message = "Good Night! 🌙";
    }

    setState(() {
      greetingMessage = message;
    });
  }

  Future<void> _pickTime(int taskIndex) async {
    TimeOfDay? selectedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (selectedTime != null) {
      String formattedTime = selectedTime.format(context);
      setState(() {
        tasks[taskIndex]["time"] = formattedTime;
        _saveTasks();
      });
    }
  }

  void _addNewTask() {
    String taskTitle = "";
    String taskDescription = "";
    String taskTime = "No Time Set";

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: Text("Add New Task", style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: "Task Name",
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  taskTitle = value;
                },
              ),
              SizedBox(height: 15),
              TextField(
                decoration: InputDecoration(
                  labelText: "Task Description",
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  taskDescription = value;
                },
              ),
              SizedBox(height: 15),
              ElevatedButton(
                onPressed: () async {
                  TimeOfDay? selectedTime = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.now(),
                  );
                  if (selectedTime != null) {
                    taskTime = selectedTime.format(context);
                  }
                },
                child: Text("Pick Time for Task"),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel", style: TextStyle(color: Colors.red)),
            ),
            ElevatedButton(
              onPressed: () {
                if (taskTitle.isNotEmpty && taskDescription.isNotEmpty) {
                  setState(() {
                    tasks.add({
                      "title": taskTitle,
                      "time": taskTime,
                      "description": taskDescription,
                      "icon": Icons.task_alt,
                    });
                    _saveTasks();
                  });
                  Navigator.pop(context);
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: Text("Add Task"),
            ),
          ],
        );
      },
    );
  }

  bool _isWeekend(DateTime day) => day.weekday == DateTime.saturday || day.weekday == DateTime.sunday;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text("👋 ", style: TextStyle(fontSize: 24)),
                Text(greetingMessage, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
        backgroundColor: Color(0xFF00DBDE),
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF00DBDE), Color(0xFFFC00FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.access_time_rounded, color: Colors.white, size: 28),
                      SizedBox(width: 8),
                      Text(
                        'MyTask Reminder',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          shadows: [
                            Shadow(blurRadius: 10.0, color: Colors.black26, offset: Offset(3.0, 3.0)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  AnimatedTextKit(
                    animatedTexts: [
                      TypewriterAnimatedText('Plan your day 📝', textStyle: TextStyle(color: Colors.white, fontSize: 16)),
                      TypewriterAnimatedText('Stay productive 💪', textStyle: TextStyle(color: Colors.white, fontSize: 16)),
                      TypewriterAnimatedText('Never miss a task ⏰', textStyle: TextStyle(color: Colors.white, fontSize: 16)),
                    ],
                    repeatForever: true,
                    pause: Duration(milliseconds: 1000),
                    displayFullTextOnTap: true,
                    stopPauseOnTap: true,
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                border: Border.all(color: Colors.white.withOpacity(0.3), width: 2),
                borderRadius: BorderRadius.circular(20),
              ),
              margin: EdgeInsets.symmetric(horizontal: 15),
              child: TableCalendar(
                firstDay: DateTime.utc(2020, 1, 1),
                lastDay: DateTime.utc(2030, 12, 31),
                focusedDay: _focusedDay,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                calendarFormat: _calendarFormat,
                headerStyle: HeaderStyle(
                  titleCentered: true,
                  formatButtonVisible: false,
                  titleTextStyle: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  leftChevronIcon: Icon(Icons.chevron_left, color: Colors.white),
                  rightChevronIcon: Icon(Icons.chevron_right, color: Colors.white),
                ),
                daysOfWeekStyle: DaysOfWeekStyle(
                  weekdayStyle: TextStyle(color: Colors.white),
                  weekendStyle: TextStyle(color: Colors.white),
                ),
                calendarBuilders: CalendarBuilders(
                  defaultBuilder: (context, day, focusedDay) {
                    return Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: _isWeekend(day) ? Colors.white70 : Colors.transparent,
                          width: 1.5,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '${day.day}',
                        style: TextStyle(color: Colors.white),
                      ),
                    );
                  },
                ),
                calendarStyle: CalendarStyle(
                  todayDecoration: BoxDecoration(color: Colors.white.withOpacity(0.8), shape: BoxShape.circle),
                  selectedDecoration: BoxDecoration(color: Colors.yellow, shape: BoxShape.circle),
                  defaultTextStyle: TextStyle(color: Colors.white),
                  weekendTextStyle: TextStyle(color: Colors.white),
                ),
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() {
                    _selectedDay = selectedDay;
                    _focusedDay = focusedDay;
                  });
                },
                onPageChanged: (focusedDay) {
                  _focusedDay = focusedDay;
                },
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.all(15),
                itemCount: tasks.length,
                itemBuilder: (context, index) {
                  return _buildTaskCard(
                    tasks[index]["title"],
                    tasks[index]["time"],
                    tasks[index]["description"],
                    tasks[index]["icon"],
                    index,
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewTask,
        backgroundColor: Color(0xFF00DBDE),
        child: Icon(Icons.add, size: 30, color: Colors.white),
        elevation: 10,
        shape: CircleBorder(),
      ),
    );
  }

  Widget _buildTaskCard(String title, String time, String description, IconData icon, int taskIndex) {
    return Card(
      color: Colors.white.withOpacity(0.9),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      elevation: 8,
      margin: EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        leading: Icon(icon, color: Color(0xFFFC00FF), size: 40),
        title: Text(
          title,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        subtitle: Text(time, style: TextStyle(fontSize: 16, color: Colors.grey[700])),
        trailing: Icon(Icons.arrow_forward, color: Colors.grey),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => TaskDetailsPage(
                title: title,
                time: time,
                description: description,
                icon: icon,
              ),
            ),
          );
        },
        onLongPress: () => _pickTime(taskIndex),
      ),
    );
  }
}
