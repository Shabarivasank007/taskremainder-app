import 'dart:convert';
import 'package:flutter/material.dart';
import 'dart:async';
import 'login_page.dart';
import 'task_details_page.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:animate_do/animate_do.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_tts/flutter_tts.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
FlutterTts flutterTts = FlutterTts(); // Instance of FlutterTts

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tz.initializeTimeZones();
  await _initializeNotifications();
  await flutterTts.setLanguage("en-US"); // Set TTS language
  await flutterTts.setSpeechRate(0.5); // Set speech rate
  await flutterTts.setPitch(1.0); // Set speech pitch
  runApp(MyApp());
}

Future<void> _initializeNotifications() async {
  const AndroidInitializationSettings initializationSettingsAndroid =
  AndroidInitializationSettings('app_icon');

  final InitializationSettings initializationSettings =
  InitializationSettings(android: initializationSettingsAndroid);

  await flutterLocalNotificationsPlugin.initialize(initializationSettings);
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Make It Happen',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: LoadingScreen(),  
    );
  }
}

class LoadingScreen extends StatefulWidget {
  @override
  _LoadingScreenState createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF00DBDE), Color(0xFFFC00FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              BounceInDown(
                child: Icon(Icons.checklist, size: 100, color: Colors.white),
              ),
              SizedBox(height: 20),
              FadeIn(
                child: Text(
                  'Make It Happen',
                  style: TextStyle(
                      fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
              SizedBox(height: 20),
              SpinKitWave(color: Colors.white, size: 50.0),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> tasks = [];
  String greetingMessage = "";

  @override
  void initState() {
    super.initState();
    _updateGreeting();
    _loadTasks();
    _removeExpiredTasks(); // Check for expired tasks when loading the app
  }

  void _updateGreeting() {
    final hour = DateTime.now().hour;
    String message;
    if (hour < 12) {
      message = "Good Morning! ☀️";
    } else if (hour < 17) {
      message = "Good Afternoon! 🌤️";
    } else if (hour < 20) {
      message = "Good Evening! 🌆";
    } else {
      message = "Good Night! 🌙";
    }
    setState(() => greetingMessage = message);
  }

  void _loadTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedTasks = prefs.getString('tasks');
    if (savedTasks != null) {
      setState(() {
        tasks = List<Map<String, dynamic>>.from(json.decode(savedTasks));
      });
    }
  }

  void _saveTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('tasks', json.encode(tasks));
  }

  void _removeExpiredTasks() {
    final now = DateTime.now();
    setState(() {
      tasks.removeWhere((task) {
        final taskTime = task["time"];
        final timeParts = taskTime.split(":");
        final taskHour = int.parse(timeParts[0]);
        final taskMinute = int.parse(timeParts[1]);

        final taskDateTime = DateTime(now.year, now.month, now.day, taskHour, taskMinute);
        return taskDateTime.isBefore(now); // Remove tasks where time has passed
      });

      _saveTasks(); // Save the updated list of tasks
    });
  }

  void _addNewTask() {
    String taskTitle = "";
    String taskDescription = "";
    String taskTime = "";

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: Text("Add New Task"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: "Task Name"),
                onChanged: (value) => taskTitle = value,
              ),
              SizedBox(height: 15),
              TextField(
                decoration: InputDecoration(labelText: "Task Description"),
                onChanged: (value) => taskDescription = value,
              ),
              SizedBox(height: 15),
              TextField(
                decoration: InputDecoration(labelText: "Task Time (HH:mm)"),
                onChanged: (value) => taskTime = value,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel", style: TextStyle(color: Colors.red)),
            ),
            ElevatedButton(
              onPressed: () {
                if (taskTitle.isNotEmpty &&
                    taskDescription.isNotEmpty &&
                    taskTime.isNotEmpty) {
                  final newTask = {
                    "title": taskTitle,
                    "time": taskTime,
                    "description": taskDescription,
                    "icon": Icons.task_alt.codePoint,
                  };

                  // Prevent duplicates
                  bool exists = tasks.any((task) =>
                  task['title'] == newTask['title'] &&
                      task['time'] == newTask['time']);
                  if (!exists) {
                    setState(() {
                      tasks.add(newTask);
                      _saveTasks();
                      _scheduleNotification(taskTitle, taskTime);
                    });
                  }
                  Navigator.pop(context);
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              child: Text("Add Task"),
            ),
          ],
        );
      },
    );
  }

  void _editTask(int index) {
    String taskTitle = tasks[index]["title"];
    String taskDescription = tasks[index]["description"];
    String taskTime = tasks[index]["time"];

    TextEditingController titleController =
    TextEditingController(text: taskTitle);
    TextEditingController descriptionController =
    TextEditingController(text: taskDescription);
    TextEditingController timeController = TextEditingController(text: taskTime);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Edit Task"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: titleController, decoration: InputDecoration(labelText: "Task Name")),
              SizedBox(height: 15),
              TextField(controller: descriptionController, decoration: InputDecoration(labelText: "Task Description")),
              SizedBox(height: 15),
              TextField(controller: timeController, decoration: InputDecoration(labelText: "Task Time (HH:mm)")),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel", style: TextStyle(color: Colors.red)),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  tasks[index] = {
                    "title": titleController.text,
                    "description": descriptionController.text,
                    "time": timeController.text,
                    "icon": Icons.task_alt.codePoint,
                  };
                  _saveTasks();
                });
                Navigator.pop(context);
              },
              child: Text("Update Task"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            ),
          ],
        );
      },
    );
  }

  void _showTaskOptions(int index) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Wrap(
            children: [
              ListTile(
                leading: Icon(Icons.edit),
                title: Text("Edit"),
                onTap: () {
                  Navigator.pop(context);
                  _editTask(index);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete, color: Colors.red),
                title: Text("Delete"),
                onTap: () {
                  setState(() {
                    tasks.removeAt(index);
                    _saveTasks();
                  });
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _scheduleNotification(String title, String time) async {
    final timeParts = time.split(":");
    final hour = int.parse(timeParts[0]);
    final minute = int.parse(timeParts[1]);

    final now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduleDate = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);

    if (scheduleDate.isBefore(now)) {
      scheduleDate = scheduleDate.add(Duration(days: 1));
    }

    const androidDetails = AndroidNotificationDetails(
      'task_channel_id',
      'Task Reminder',
      channelDescription: 'Reminder Channel',
      importance: Importance.max,
      priority: Priority.high,
    );

    const notificationDetails = NotificationDetails(android: androidDetails);

    await flutterLocalNotificationsPlugin.zonedSchedule(
      DateTime.now().millisecondsSinceEpoch.remainder(100000),
      title,
      'Reminder: $title',
      scheduleDate,
      notificationDetails,
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
      UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );

    // Add TTS functionality to speak the reminder
    await flutterTts.speak('Reminder: $title at $time');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(greetingMessage), backgroundColor: Color(0xFF00DBDE)),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF00DBDE), Color(0xFFFC00FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: tasks.isEmpty
            ? Center(child: Text("No tasks yet!", style: TextStyle(color: Colors.white, fontSize: 18)))
            : ListView.builder(
          itemCount: tasks.length,
          padding: EdgeInsets.all(12),
          itemBuilder: (context, index) {
            final task = tasks[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (_) => TaskDetailsPage(
                    title: task["title"],
                    time: task["time"],
                    description: task["description"],
                    icon: IconData(task["icon"], fontFamily: 'MaterialIcons'),
                  ),
                ));
              },
              onLongPress: () => _showTaskOptions(index),
              child: Card(
                color: Colors.white.withOpacity(0.9),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                child: ListTile(
                  leading: Icon(IconData(task["icon"], fontFamily: 'MaterialIcons'), color: Color(0xFFFC00FF)),
                  title: Text(task["title"], style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text("${task["description"]}\n⏰ ${task["time"]}"),
                  isThreeLine: true,
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewTask,
        child: Icon(Icons.add),
        backgroundColor: Color(0xFFFC00FF),
      ),
    );
  }
}
