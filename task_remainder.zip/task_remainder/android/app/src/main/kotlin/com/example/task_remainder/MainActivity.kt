package com.example.task_remainder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
